import { Component, OnInit,Input, Output, EventEmitter, } from '@angular/core';
import {ColumnList} from '../model/column-list'
import {Sale} from '../model/saleItem.model'
import { Action } from '@ngrx/store';


@Component({
  selector: 'nx-angular-test-item-list',
  templateUrl: './item-list.component.html',
  styleUrls: ['./item-list.component.scss']
})
export class ItemListComponent implements OnInit {
 SaleColumn:any; 
 @Input() dataSource: any;
 Empty="No items for sale.";
  constructor() { 
    const columns=new ColumnList();
    this.SaleColumn=columns.screenmediaSale.split(',');

   }

  ngOnInit(): void {
    
  }


}
