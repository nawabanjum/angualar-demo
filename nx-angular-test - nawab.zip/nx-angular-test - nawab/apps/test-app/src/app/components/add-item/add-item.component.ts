import { Component, OnInit } from '@angular/core';

import { FormGroup, Validators, FormBuilder } from '@angular/forms';

@Component({
  selector: 'nx-angular-test-add-item',
  templateUrl: './add-item.component.html',
  styleUrls: ['./add-item.component.scss']
})
export class AddItemComponent implements OnInit {  
  form!: FormGroup;
  submitted = false;
  constructor(
    private formBuilder: FormBuilder,
  ) { 

  }

  ngOnInit() {
    this.form = this.formBuilder.group({
      Title: ['', [Validators.required]],
      Description: [''],
      Price: ['', [Validators.required]]
    });
  }
// convenience getter for easy access to form fields
get f() {
  return this.form.controls;
}
  addSaleItem() {
    window.alert()
    if (!this.form.valid) {
      return;
    }
}
}
