export interface Sale {
    Id: Number;
    Title: string,
    Description: string;
    Price: Number;    
  }