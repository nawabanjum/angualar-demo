export class ColumnList {
    screenmediaSale: string;
    constructor() {
        this.screenmediaSale = 'Item Title, Description,Price';
    }
}
